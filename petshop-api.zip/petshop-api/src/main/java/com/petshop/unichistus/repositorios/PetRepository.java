package com.petshop.unichistus.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;

import com.petshop.unichistus.entidades.Pet;

public interface PetRepository extends JpaRepository<Pet, Long> {

}
