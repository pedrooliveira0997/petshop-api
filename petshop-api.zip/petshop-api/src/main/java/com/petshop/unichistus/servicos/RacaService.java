package com.petshop.unichistus.servicos;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.petshop.unichistus.entidades.Raca;
import com.petshop.unichistus.repositorios.RacaRepository;


@Service
public class RacaService {
	
	@Autowired
	private RacaRepository repo;
	
	public void salvar(Raca raca) {
		this.repo.save(raca);
	}
}

