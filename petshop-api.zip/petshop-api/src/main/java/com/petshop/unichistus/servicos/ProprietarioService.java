package com.petshop.unichistus.servicos;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.petshop.unichistus.entidades.Proprietario;
import com.petshop.unichistus.repositorios.ProprietarioRepository;


@Service
public class ProprietarioService {
	
	@Autowired
	private ProprietarioRepository repo;
	
	public void salvar(Proprietario proprietario) {
		this.repo.save(proprietario);
	}
}

