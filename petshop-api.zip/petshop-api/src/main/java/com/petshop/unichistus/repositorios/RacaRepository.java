package com.petshop.unichistus.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;

import com.petshop.unichistus.entidades.Raca;

public interface RacaRepository extends JpaRepository<Raca, Long> {

}
