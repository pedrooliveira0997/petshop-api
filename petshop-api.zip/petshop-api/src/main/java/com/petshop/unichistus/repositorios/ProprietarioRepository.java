package com.petshop.unichistus.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;

import com.petshop.unichistus.entidades.Proprietario;

public interface ProprietarioRepository extends JpaRepository<Proprietario, Long> {

}
