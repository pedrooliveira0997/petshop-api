package com.petshop.unichistus.entidades;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "TB_RACA")
	public class Raca {

		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Column(name = "RACA_ID")
		private Long racaID;

		@Column(name = "NOME")
		private String nome;
		
		@Column(name = "PAIS_ORIGEM")
		private String pais;

		public Raca(String nome, String pais) {
			super();
			this.nome = nome;
			this.pais = pais;
		}

		@Override
		public String toString() {
			return "Raca [racaID=" + racaID + ", nome=" + nome + ", pais=" + pais + "]";
		}
		
		
		
		

}
