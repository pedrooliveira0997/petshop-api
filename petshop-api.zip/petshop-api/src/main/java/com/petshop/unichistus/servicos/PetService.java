package com.petshop.unichistus.servicos;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.petshop.unichistus.entidades.Pet;
import com.petshop.unichistus.repositorios.PetRepository;


@Service
public class PetService {
	
	@Autowired
	private PetRepository repo;
	
	public void salvar(Pet pet) {
		this.repo.save(pet);
	}
}

