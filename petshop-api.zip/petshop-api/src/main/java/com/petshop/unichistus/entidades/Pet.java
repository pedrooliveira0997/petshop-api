package com.petshop.unichistus.entidades;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "TB_PET")
	public class Pet {

		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Column(name = "PET_ID")
		private Long petID;

		@Column(name = "NOME")
		private String nome;
		
		@Column(name = "DATA_NASCIMENTO")
		private LocalDate dataNasc;
		
		@Column(name = "SEXO")
		private char sexo;

		public Pet(String nome, LocalDate dataNasc, char sexo) {
			super();
			this.nome = nome;
			this.dataNasc = dataNasc;
			this.sexo = sexo;
		}

		@Override
		public String toString() {
			return "Pet [petID=" + petID + ", nome=" + nome + ", dataNasc=" + dataNasc + ", sexo=" + sexo + "]";
		}

}
