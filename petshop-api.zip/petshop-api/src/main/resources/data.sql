insert into tb_proprietario(proprietario_id, nome) values(1,'Pedro');
insert into tb_proprietario(proprietario_id, nome) values(2,'Lucas');
insert into tb_proprietario(proprietario_id, nome) values(3,'Isaac');
insert into tb_proprietario(proprietario_id, nome) values(4,'Victor');
insert into tb_proprietario(proprietario_id, nome) values(5, 'Marcio');
insert into tb_proprietario(proprietario_id, nome) values(6,'Angelo');


insert into tb_pet(pet_id, nome, data_nascimento, sexo) values (1,'Ralf', '1954-11-08', 'M');
insert into tb_pet(pet_id, nome, data_nascimento, sexo) values (1,'Lessi', '1965-11-10', 'F');
insert into tb_pet(pet_id, nome, data_nascimento, sexo) values (1,'Megui', '1980-11-23', 'F');
insert into tb_pet(pet_id, nome, data_nascimento, sexo) values (1,'Zeus', '1976-11-30', 'M');
insert into tb_pet(pet_id, nome, data_nascimento, sexo) values (1,'Zulu', '1980-11-14', 'F');
insert into tb_pet(pet_id, nome, data_nascimento, sexo) values (1,'Mike', '1960-11-27', 'M');

insert into tb_raca(raca_id, nome, pais_origem) values(1,'Pitbull','USA');
insert into tb_raca(raca_id, nome, pais_origem) values(2,'Bulldog','USA');
insert into tb_raca(raca_id, nome, pais_origem) values(3,'Husk','Russia');
insert into tb_raca(raca_id, nome, pais_origem) values(4,'Fila','Brasil');
insert into tb_raca(raca_id, nome, pais_origem) values(5,'Pudle','Espanha');
insert into tb_raca(raca_id, nome, pais_origem) values(6,'Pastor Alemao','Alemanha');

